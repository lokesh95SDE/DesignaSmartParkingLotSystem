package org.ParkingLotSystem.enums;

public enum VehicalType {
    SMALL,
    MEDIUM,
    LARGE
}
