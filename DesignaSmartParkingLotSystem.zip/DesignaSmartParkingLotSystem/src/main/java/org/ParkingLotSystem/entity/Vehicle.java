package org.ParkingLotSystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.ParkingLotSystem.enums.VehicalType;

@Entity
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long vehicalId;
    private String registrationNumber;
    private VehicalType vehicalType;
}
