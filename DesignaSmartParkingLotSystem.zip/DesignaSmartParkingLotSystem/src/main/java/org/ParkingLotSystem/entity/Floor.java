package org.ParkingLotSystem.entity;

import jakarta.persistence.*;

@Entity
public class Floor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long floorId;

    private Integer floorNumber;

    @ManyToOne
    private ParkingLot parkingLot;
}
